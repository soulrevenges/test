import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.DatagramSocket;
import java.net.MulticastSocket;
import java.net.UnknownHostException;
import java.util.Random;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class server {

    final static String INET_ADDR = "224.0.0.3";
    final static int PORT_S = 10308;
	final static int PUERTO = 9308;
	public static void main(String[] args) throws UnknownHostException, InterruptedException, IOException {
        serverTV st=new serverTV();
        try{
        st.start();	
        }
        catch(Exception e){
        	throw e;
        }
		enviarData(INET_ADDR);	
		}
	
	public static void enviarData(String ip) throws UnknownHostException, InterruptedException, IOException {
		//Creación archivo de respaldo
		File archivo = new File("Historial.txt");
        FileWriter bw;
		
		// Get the address that we are going to connect to.
		InetAddress addr = InetAddress.getByName(ip);
		
		byte[] buf = new byte[256];

		// Open a new DatagramSocket, which will be used to send the data.
		try (DatagramSocket serverSocket = new DatagramSocket()) {
			
			for (int i = 1; i >= 0; i++) {
				Random rand = new Random();
				int  n1 = rand.nextInt(1024);
				int  n2 = rand.nextInt(1024);
				int  n3 = rand.nextInt(1024);
				int  n4 = rand.nextInt(1024);

				String msg = String.format("%d::(%s,%s,%s,%s)",i,n1,n2,n3,n4);

				// Create a packet that will contain the data
				// (in the form of bytes) and send it.
				DatagramPacket msgPacket = new DatagramPacket(msg.getBytes(),
						msg.getBytes().length, addr, PORT_S);
				serverSocket.send(msgPacket);
				
				
				if(archivo.exists()) {
					bw = (new FileWriter(archivo,true));
					bw.write(msg +"\n");
				} else {
					System.out.println("asd");
					bw = (new FileWriter(archivo));
					bw.write(msg +"\n");
				}
	  
				System.out.println("\nServer sent packet with msg: " + msg);
				bw.close();
				Thread.sleep(2000);
				}
				
			//Cerrado archivo de historial
			}catch (IOException ex) {
				ex.printStackTrace();
				}			
		}
}
class serverTV extends Thread{
    final static String INET_ADDR = "224.0.0.3";
    final static int PORT_S = 8888;
	final static int PUERTO=8889;
	private static Socket socket;
    private static ServerSocket serverSocket;
    private static DataInputStream bufferDeEntrada = null;
    private static DataOutputStream bufferDeSalida = null;
	static int STATE=0;
		
	//LECTOR DE ARCHIVOS
	public void run(){
		try{
		while(true){
		func();		
		}
		}
		catch(InterruptedException e)
		{
			throw new RuntimeException("Something to explain what is happening", e);
		}
		catch(UnknownHostException e)
		{
			throw new RuntimeException("Something to explain what is happening", e);
		}
		catch(IOException e)
		{
			throw new RuntimeException("Something to explain what is happening", e);
		}
	}
	public static void func()throws UnknownHostException, InterruptedException, IOException{
				serverTV servidor = new serverTV();
		try{
			servidor.levantarConexion(PUERTO);
			servidor.flujos();
			String file ="Historial.txt";		
			String hist = servidor.recibirDatos();
			if ( hist.equals("1")){
					servidor.mostrarContenido(file); // Se envía historial desde txt	
				
					servidor.enviar("Servidor Ocupado");				
				}
			}finally {
				servidor.mostrarTexto("Servidor cierra conexion");
				servidor.cerrarConexion();
				}
	}
	public static void mostrarContenido(String archivo) throws FileNotFoundException, IOException {
        String cadena;
        FileReader f = new FileReader(archivo);
        BufferedReader b = new BufferedReader(f);
        while((cadena = b.readLine())!=null) {
            enviar(cadena);
			}
        b.close();
	}
		
	/*** SERVIDOR ***/
	//Levanta conexión
    public void levantarConexion(int puerto) {
        try {
            serverSocket = new ServerSocket(puerto); //creo socket
            serverSocket.setReuseAddress(true);
            mostrarTexto("Esperando conexión entrante en el puerto " + String.valueOf(puerto) + "...");
            socket = serverSocket.accept(); //acepta conexión
            mostrarTexto("Conexión establecida con: " + socket.getInetAddress().getHostName() + "\n\n\n");
        } catch (Exception e) {
            mostrarTexto("Error en levantarConexion(): " + e.getMessage());
            System.exit(0);
        }
    }	
    
    //imprime mensaje
    public static void mostrarTexto(String s) {
        System.out.print(s);
    }
    
    // verifica si hay mensajes recibidos o para enviar
    // setea variables y asegura de que no quede nada sin pasar
    public void flujos() {
        try {
            bufferDeEntrada = new DataInputStream(socket.getInputStream()); 
            bufferDeSalida = new DataOutputStream(socket.getOutputStream());
            bufferDeSalida.flush();
        } catch (IOException e) {
            mostrarTexto("Error en la apertura de flujos");
        }
    }
    
    //Recibe datos
    public String recibirDatos() {
        String st = "";
        try {
			st = (String) bufferDeEntrada.readUTF(); //Hay mensaje recibido?
        } catch (IOException e) {
            cerrarConexion();
        }
        return st;
    }
    
    //envia mensaje
    public static void enviar(String s) {
        try {
            bufferDeSalida.writeUTF(s);
            bufferDeSalida.flush();
        } catch (IOException e) {
            mostrarTexto("Error en enviar(): " + e.getMessage());
        }
    }
    
    //cierra conexion
    public void cerrarConexion() {
        try {
            bufferDeEntrada.close();
            bufferDeSalida.close();
            socket.close();
            serverSocket.close();
        } catch (IOException e) {
          mostrarTexto("Excepción en cerrarConexion(): " + e.getMessage());
        } finally {
            mostrarTexto("Conversación finalizada....\n");
            STATE=0;
            //System.exit(0);

        }
    }
}
