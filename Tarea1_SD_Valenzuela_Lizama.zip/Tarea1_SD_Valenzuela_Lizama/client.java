import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.DatagramSocket;
import java.net.MulticastSocket;
import java.net.UnknownHostException;
import java.util.*;
import java.net.*;
import java.io.*;

public class client {
    
    final static String INET_ADDR = "224.0.0.3";
    final static int PORT_S = 10308;
	final static int PORT_C = 9308;

    public static void main(String[] args) throws UnknownHostException {


        leerData(args);
    }
    
    public static void leerData(String[] host) throws UnknownHostException {
		// Get the address that we are going to connect to.
        if (host.length <3) {
                System.out.println("Wrong Number of params");
                return;
        }
        InetAddress address = InetAddress.getByName(host[0]);
        String channelToRead = host[1];
        String history = host[2];
        // Create a buffer of bytes, which will be used to store
        // the incoming bytes containing the information from the server.
        // Since the message is small here, 256 bytes should be enough.
        byte[] buf = new byte[256];
        
        // Create a new Multicast socket (that will allow other sockets/programs
        // to join it as well.
        if (history.equals("1")) {
            clientTV client=new clientTV();
            try{
            client.start(); 
            }
            catch(Exception e){
                throw e;
            }
        }
                try (MulticastSocket clientSocket = new MulticastSocket(PORT_S)){
                    //Joint the Multicast group.
                    clientSocket.joinGroup(address);
             
                    while (true) {
                        // Receive the information and print it.
                        DatagramPacket msgPacket = new DatagramPacket(buf, buf.length);
                        clientSocket.receive(msgPacket);

                        String msg = new String(buf, 0, buf.length);
                        String[] datas= msg.split("::")[1].replace("(","").replace(")","").trim().split(",");
                        int len = channelToRead.length();
                        List<String> list = new ArrayList<String>();
                        for (int i = 0; i < len; i++) {
                            if (channelToRead.charAt(i)=='1') {
                            list.add(datas[i]);
                            }
                        }
                        System.out.println("Socket 1 received msg: " + String.join(",",list));
        				}
        			} catch (IOException ex) {
        				ex.printStackTrace();
        				}
        		}

	}
class clientTV  extends Thread{
    
    final static String HOST = "localhost";
    final static int PUERTO_H=8889; 
    private static Socket socket;
    private static DataInputStream bufferDeEntrada = null;
    private static DataOutputStream bufferDeSalida = null;

    public void run(){
        func();     
        }
    public static void func(){     
        String hist = "1";
        clientTV cliente = new clientTV();
        try {
                cliente.levantarConexion(HOST, PUERTO_H);
                mostrarTexto("Server UP\n");
                cliente.abrirFlujos();
                cliente.enviar(hist);
                cliente.recibirDatos();

        } finally {
            mostrarTexto("Conection close");
            cliente.cerrarConexion();
        }
    }
        
    //crea socket
    public static void levantarConexion(String ip, int puerto) {
        try {
            socket = new Socket(ip, puerto);
            mostrarTexto("Connected with: " + socket.getInetAddress().getHostName());
        } catch (Exception e) {
            mostrarTexto("Excepción al levantar conexión: " + e.getMessage());
            //System.exit(0);
        }
    }   
    
    //impirme texto
    public static void mostrarTexto(String s) {
        System.out.println(s);
    }
    
    //maneja mensajes de entrada vs salida
    public void abrirFlujos() {
        try {
            bufferDeEntrada = new DataInputStream(socket.getInputStream());
            bufferDeSalida = new DataOutputStream(socket.getOutputStream());
            bufferDeSalida.flush();
        } catch (IOException e) {
            mostrarTexto("Error en la apertura de flujos");
        }
    }
    
    //envia mensaje
    public void enviar(String s) {
        try {
            bufferDeSalida.writeUTF(s);
            bufferDeSalida.flush();
        } catch (IOException e) {
            mostrarTexto("IOException on enviar");
        }
    }
        
    //recibe datos xD
    public void recibirDatos() {
        String st = "";
        FileWriter bw;
        try {
            mostrarTexto("Getting history file information from server...");
            while (true){
                st = (String) bufferDeEntrada.readUTF();
                bw = (new FileWriter("HistoricalRecovered.txt",true));
                bw.write(st +"\n");
                //mostrarTexto("\n[Servidor] => " + st);
                //System.out.print("\n[Usted] => ");
                bw.close();
            }
        } catch (IOException e) {
        mostrarTexto("File error");
        }
        mostrarTexto("File its ready");
    }
    
     //cierra conexión
    public void cerrarConexion() {
        try {
            bufferDeEntrada.close();
            bufferDeSalida.close();
            socket.close();
            mostrarTexto("Conection Close");
        } catch (IOException e) {
            mostrarTexto("IOException on cerrarConexion()");
        }finally{
            //System.exit(0);
        }
    }  
}
